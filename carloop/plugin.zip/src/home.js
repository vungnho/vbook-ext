function execute() {
    return Response.success([
        { title: "Mới cập nhật", input: "https://carloop.io/?page=", script: "gen.js" }
    ]);
}
